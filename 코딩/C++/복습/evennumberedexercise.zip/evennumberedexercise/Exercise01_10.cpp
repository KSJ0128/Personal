#include <iostream>
using namespace std;

int main()
{
  cout << (14 / 45.5) * 60 / 1.6 << endl;

  return 0;
}
