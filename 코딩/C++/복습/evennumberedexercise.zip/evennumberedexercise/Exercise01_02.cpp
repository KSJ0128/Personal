#include <iostream>
using namespace std;

int main()
{
  cout << "Welcome to C++" << endl;
  cout << "Welcome to C++" << endl;
  cout << "Welcome to C++" << endl;
  cout << "Welcome to C++" << endl;
  cout << "Welcome to C++" << endl;

  return 0;
}
