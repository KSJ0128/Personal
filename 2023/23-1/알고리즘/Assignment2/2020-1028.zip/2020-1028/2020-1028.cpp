#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>

using namespace std;

// GA 매개 변수
const int MAX_V = 500; // 최대 정점 개수
const int MAX_E = 5000;   // 최대 간선 개수
const int POPULATION_SIZE = 1000; // 개체 집단 크기
const int MAX_GENERATIONS = 1000; // 최대 세대 수
const int TIME_LIMIT = 179; // 제한 시간

struct Edge {
    int s; // 출발
    int d; // 도착
    int w; // 가중치
};

// 개체 구조
struct Individual {
    int chromosome[MAX_V]; // 최대 정점 개수 = MAX_V
    int fitness;
};

// 그래프 정보
Edge edges[MAX_E]; // 최대 간선 개수 = MAX_E
int v; // # of 정점
int e; // # of 간선

// 개체 집단을 초기화하는 함수
void initializePopulation(Individual population[]) {
    for (int i = 0; i < POPULATION_SIZE; i++) {
        for (int j = 0; j < v; j++) {
            population[i].chromosome[j] = rand() % 2; // 0 또는 1로 초기화
        }
        population[i].fitness = 0;
    }
}

// 개체의 적합도(가중치 합)를 계산하는 함수
void calculateFitness(Individual& individual) {
    int totalWeight = 0;
    for (int i = 0; i < e; i++) {
        if (individual.chromosome[edges[i].s] != individual.chromosome[edges[i].d]) {
            totalWeight += edges[i].w;
        }
    }
    individual.fitness = totalWeight;
}

// 개체를 비교하여 더 우수한 개체(가중치가 더 큰 것)를 반환하는 함수
Individual compareIndividuals(const Individual& individual1, const Individual& individual2) {
    if (individual1.fitness > individual2.fitness) { // 적합도(가중치 합) 비교
        return individual1;
    } else {
        return individual2;
    }
}

// 두 개체를 교차하는 함수
Individual crossover(const Individual& parent1, const Individual& parent2) {
    Individual child;
    
    // 랜덤하게 교차점 선택
    int crossoverPoint = rand() % v;

    // 첫 번째 부분을 부모 1로부터 복사
    for (int i = 0; i < crossoverPoint; i++) {
        child.chromosome[i] = parent1.chromosome[i];
    }

    // 두 번째 부분을 부모 2로부터 복사
    for (int i = crossoverPoint; i < v; i++) {
        child.chromosome[i] = parent2.chromosome[i];
    }

    return child;
}

// 개체를 돌연변이시키는 함수
void mutate(Individual& individual) {
    int mutationPoint = rand() % v;
    individual.chromosome[mutationPoint] = 1 - individual.chromosome[mutationPoint]; // 비트 반전
}

// Local Search
void localSearch(Individual& individual) {
    bool improved = true;
    int localFitness = individual.fitness;

    while (improved) { // 더 이상 개선이 없을 때까지 반복
        improved = false;

        for (int i = 0; i < v; i++) {
            Individual localIndividual = individual; // 지역 개체 복사
            localIndividual.chromosome[i] = 1 - localIndividual.chromosome[i]; // 지역 개체 인덱스 반전 
            calculateFitness(localIndividual); // 수정된 개체 적합도 계산

            if (localIndividual.fitness > localFitness) { // 수정된 개체 적합도 지역 개체 적합도보다 높으면
                individual = localIndividual; // 지역 최적해 업데이트
                localFitness = localIndividual.fitness; // 지역 개체 적합도 업데이트
                improved = true; // 개선됨 true로 바꿈
            }
        }
    }
}

int main() {
    // 시작 시간 기록
    time_t startTime = time(nullptr); 

    // 그래프 정보를 파일로부터 입력받기
    ifstream inputFile("weighted_500.txt");
    ofstream outputFile("weighted_500.txt");

    if (!inputFile) {
        cerr << "Failed to open file." << endl;
        return 1;
    }

    // 정점 개수와 간선 개수 입력 받기
    inputFile >> v >> e; // 파일의 맨 첫 줄

    // 간선 정보 입력 받기
    for (int i = 0; i < e; i++) {
        inputFile >> edges[i].s >> edges[i].d >> edges[i].w;
    }
    inputFile.close();

    // 개체 집단 생성 및 초기화
    Individual population[POPULATION_SIZE];
    Individual bestIndividual;
    initializePopulation(population);

    // 유전 알고리즘 반복
    while (true) {
        // 개체 적합도(가중치 합) 계산
        for (int i = 0; i < POPULATION_SIZE; i++) {
            calculateFitness(population[i]);
        }

        // 현재 개체가 최적해보다 우수하다면 최적해 업데이트
        bestIndividual = population[0];
        for (int i = 1; i < POPULATION_SIZE; i++) {
            bestIndividual = compareIndividuals(bestIndividual, population[i]);
        }

        // Local Search Algorithm을 이용하여 개체 집단 탐색
        for (int i = 0; i < POPULATION_SIZE; i++) {
            localSearch(population[i]);
        }

        // 새로운 개체 집단 생성
        Individual newPopulation[POPULATION_SIZE];

        srand((unsigned int)time(NULL)); // 랜덤함수 생성 위해

        // 개체 선택, 교차, 돌연변이 수행
        for (int i = 0; i < POPULATION_SIZE; i++) {
            // 개체 선택 (토너먼트 선택)
            int parentIndex1 = rand() % POPULATION_SIZE;
            int parentIndex2 = rand() % POPULATION_SIZE;

            Individual parent1 = population[parentIndex1];
            Individual parent2 = population[parentIndex2];

            // Crossover
            Individual child = crossover(parent1, parent2);

            // Mutation
            if (rand() % 100 < 10) { // 10% 확률로 돌연변이 발생
                mutate(child);
            }

            // 새로운 개체 집단에 추가
            newPopulation[i] = child;
        }

        // 새로운 개체 집단으로 업데이트
        for (int i = 0; i < POPULATION_SIZE; i++) {
            population[i] = newPopulation[i];
        }

        // 제한 시간 체크
            time_t currentTime = time(nullptr);

            if (currentTime - startTime >= TIME_LIMIT) {
                break; // 제한 시간을 초과하면 반복 종료
            }
    }    

    // 최적해 출력
    for (int i = 0; i < v; i++) {
        if (bestIndividual.chromosome[i] == 1) {
            outputFile << i + 1 << " ";
        }
    }

    outputFile << endl;
    outputFile.close();

    /*
    // 최적해 출력
    for (int i = 0; i < v; i++) {
        if (bestIndividual.chromosome[i] == 1) {
            cout << i << " ";
        }
    }
    cout << endl;

    calculateFitness(bestIndividual);
    cout << bestIndividual.fitness;
    */
   
    return 0;
}